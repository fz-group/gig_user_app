
import 'package:get/get.dart';

const String kAppName = "FreeLancers";
const String currency=//'دينار جزائري';
" DA";
 String days='days'.tr;




import 'package:get/get.dart';

class EmpController extends GetxController {


}
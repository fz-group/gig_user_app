// ignore_for_file: constant_identifier_names

class Routes {
  static const LOGIN = '/login';
 // static const SERVICE_DETAILS ='/ServiceDetailsView';
  static const REGISTER = '/register';
  static const HOME = '/home';
  static const USERS = '/users';
  static const ROOT = '/root';
  static const SERVICEDETAILS = '/service_details';
  static const SPLASH = '/splash';
  static const PROFILE = '/profile';
    static const CART = '/cart';
    static const LOCATION = '/location';
    static const MAP = '/map';

}
